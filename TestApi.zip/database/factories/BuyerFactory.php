<?php

use Faker\Generator as Faker;

$factory->define(App\Buyer::class, function (Faker $faker) {
    return [
        //
    ];
});
